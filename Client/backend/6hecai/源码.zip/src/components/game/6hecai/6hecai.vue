<template>
  <div class="contanier">

    <!-- 固定头部 -->
    <dentGameHeader v-on:onselect="onSwitch"
                    v-on:onClickRightOrder="$router.push({name:'6hecaiwaiForPay',query:{getOrder:false}})"
                    v-on:onClickOpr="onClickOpr"
                    :obj="odds">
      <span slot="tips">玩法</span>
    </dentGameHeader>

    <div class="flex-wrap flex flow-col">
      

      <!-- 子玩法切换 -->
      <switchTab v-if="needSwitch && currentOdds !== 'lqlw'"
                 :tabObj="odds[currentOdds]"
                 :type="currentOdds"
                 v-model="activeTab"></switchTab>
      <!-- 连肖连尾特殊处理                  -->
      <switchTab v-else-if="needSwitch && currentOdds === 'lqlw'"
                 :tabObj="odds.lqlw.show"
                 :type="currentOdds"
                 v-model="activeTab"></switchTab>
      <!-- 合肖特殊处理 -->     

      <!-- 下注信息展示区 -->
      <div :class="!Object.keys(odds).length?'justify-ct':''"
           class="odds-wrap flex flow-col">
        <!-- loading提示 -->
        <mt-spinner v-if="!Object.keys(odds).length"
                    color="#e62b00"
                    type="fading-circle"></mt-spinner>
        <!-- 内容区 -->
        <template v-else>
          <template v-if="needSwitch">
            <mt-tab-container swipeable="true"
                              v-model="activeTab">
              <!-- 连肖连尾特殊处理 -->
              <mt-tab-container-item v-if="currentOdds === 'lqlw'"
                                     v-for="(value,key,index) in odds.lqlw.show"
                                     :id="index"
                                     :key="index">
                <bets v-if="activeTab === index"
                      :betsObj="value"
                      v-model="shouldCommit"
                      :type="currentOdds"
                      :activeTab="activeTab"
                      :haoma="haoma"
                      v-on:changebets="changebets"
                      :currentSubOdds="currentSubOdds"
                      v-on:oddsTips="oddsTips=true"></bets>
              </mt-tab-container-item>
              <mt-tab-container-item v-else
                                     v-for="(value,key,index) in odds[currentOdds]"
                                     :id="index"
                                     :key="index">
                <bets v-if="activeTab === index"
                      :betsObj="value"
                      v-model="shouldCommit"
                      :type="currentOdds"
                      :activeTab="activeTab"
                      :haoma="haoma"
                      v-on:changebets="changebets"
                      :currentSubOdds="currentSubOdds"
                      v-on:oddsTips="oddsTips=true"></bets>
              </mt-tab-container-item>

            </mt-tab-container>
          </template>
          <!-- 合肖特殊处理 -->
          <template v-else-if="currentOdds === 'hq'">
            <bets :betsObj="odds.hq.show"
                  v-model="shouldCommit"
                  :haoma="haoma"
                  v-on:changebets="changebets"
                  :currentSubOdds="currentOdds"
                  v-on:oddsTips="oddsTips=true"></bets>
          </template>
          <template v-else>
            <bets :betsObj="odds[currentOdds]"
                  v-model="shouldCommit"
                  :haoma="haoma"
                  v-on:changebets="changebets"
                  :currentSubOdds="currentOdds"
                  v-on:oddsTips="oddsTips=true"></bets>
          </template>         
        </template>
        
      </div>

      <!-- 底部下注栏 -->
      <div class="hecai-bottom flex justify-sb bgc-fff">
        <mt-button style="left:150px;background-color: #eade43"  @click="submit" >提交</mt-button>
       
      </div>

    </div>



  </div>
</template>

<script>
import { Toast } from 'mint-ui';
import dentGameHeader from "@/components/common/dentGameHeader";
import switchTab from "./compoent-switch";
import bets from "./compoent-bets";
import { keyToCharacter } from "@/js/6hecai-odds";

export default {
  components: {
    dentGameHeader,
    switchTab,
    bets
  },
  filters: {
    // 键值转成中文
    keyToCharacter: function(value) {
      let character = "";
      for (let key in keyToCharacter) {
        if (key === value) {
          character = keyToCharacter[key];
          break;
        }
      }
      !character && (character = value);
      return character;
    }
  },
  data() {
    return {
      /* 数据相关 */
      shengxiao: "", //当前生肖年 用在合肖和连肖连尾
      odds: {}, //全部赔率信息
      haoma: {}, //生肖和五行号码          
      currentOdds: "lm", //当前选择的大玩法（默认第一种）
      shouldCommit: [], //用户的下注信息 
      modifiedArray: [],

      /* 状态相关 */      
      showTip: false,
      activeTab:0,
    };
  },
  computed: {
    // 玩法是否有子玩法切换
    needSwitch() {
      let needSwitchOdds = [
        "qmwx",
        "wsh",
        "sb",
        "shx",
        "zxbzh",
        "lqlw",
        "lma",
        "zhm1-6",
        "zhmt",
        "zhy"
      ];

      return needSwitchOdds.includes(this.currentOdds);
    },
    //当前选择的子玩法
    currentSubOdds() {
      
      let currentSubOdds = "";
      let { odds, currentOdds, activeTab } = this;
      let lqlw = currentOdds === "lqlw"; //连肖连尾特殊处理
      if (lqlw) {
        currentSubOdds = Object.keys(odds.lqlw.show)[activeTab];
      } else {
        currentSubOdds =
          this.needSwitch && Object.keys(odds[currentOdds])[activeTab];
      }

      return currentSubOdds;
    }
  },
  mounted: function() {
    this.$parent.tabbarShow = false;
    this.getOddsData();
  },
  activated(){
    this.$parent.tabbarShow = false;
  },
  methods: {
    //切换不同的玩法
    onSwitch(val) {
      this.currentOdds = val;
      //将激活的tab改为0 ，清空下注信息
      this.canEarn = this.totalBets = this.activeTab = 0;
      this.shouldCommit = [];
    },

    //请求 赔率 数据
    getOddsData() {
      this.$axios
        .get("http://192.168.2.100/bc/Index/Settingodds/settingSix", {})
        .then(res => {        
          this.odds = res.data.odds;
          this.haoma = res.data.haoma
          console.log(res);
          if (res.status === 200) {
            console.log("获取成功");
          } else {
            console.log("获取失败");
          }
        });

    },
    //接收从conpoent-bets页传来的数据
    changebets(data) {
      console.log(data);
      console.log(140);
      this.modifiedArray.push(data);
    },

    submit() {
      this.$axios.post("http://192.168.2.100/bc/Index/Settingodds/settingSix", {
        odds: this.modifiedArray
      }).then(res => {
        var res = res.data
        console.log(222222222222)
        console.log(res)
        if(res.code === 1 ){
          Toast({
                  message: '修改成功',
                  iconClass: 'icon icon-success'
                });
            console.log("修改成功");
        }
        
      })
    }
  },

};
</script>

<style scoped>
.hoverclass {
  background: rgba(230, 70, 0, 0.1);
  box-shadow: none;
}
.theme-hoverclass {
  background: rgba(230, 65, 0, 0.2) !important;
}
.slideUp-enter-active,
.slideUp-leave-active {
  will-change: transform;
  transition: 0.35s;
  transform: translate3d(0, 0, 0);
}
.slideUp-enter,
.slideUp-leave-to {
  transform: translate3d(0, 100%, 0);
}

.fadeIn-enter-active,
.fadeIn-leave-active {
  will-change: opacity;
  transition: opacity 500ms;
}
.fadeIn-enter,
.fadeIn-leave-to {
  opacity: 0;
}
.contanier {
  padding-top: 13.8vw;
  background: #ffffff;
}
.flex-wrap {
  height: calc(100vh - 13.8vw);
}
.fz12 {
  font-size: 12px;
}
.odds-wrap {
  flex: 1;
  position: relative;
  width: 100%;
  overflow: auto;
}
.mint-tab-container {
  flex: 1;
  width: 100%;
  height: 100%;
  overflow: auto;
}
.mint-tab-container-wrap {
  height: 100%;
}
/* 开奖信息 */
.open {
  width: 100%;
  height: 24vw;
}
.count-down {
  font-size: 14px;
  letter-spacing: 0.1em;
}
.time-left {
  width: 36vw;
  padding-right: 3vw;
  height: 14.4vw;
  border-right: 1px solid #ebebeb;
}
.open-num {
  flex: 1;
  height: 20vw;
}
.open-num .icon-arrow-down {
  font-size: 12px;
  transition: 0.5s;
}
._arrow-down {
  transform: rotate(180deg);
}
.balls-item,
.balls-spec-item {
  margin: 0.5vw;
  width: 6vw;
  height: 6vw;
  background: #e64600;
  font-size: 12px;
  line-height: 6vw;
  text-align: center;
  color: #fff;
  border-radius: 50%;
}
.balls-spec-item {
  background: #008000;
}
.balls-text {
  color: #535353;
}
.balls-link {
  position: relative;
  top: -0.5em;
  margin: 1vw;
}

.open-lately {
  width: 100%;
  transition: 0.5s;
  height: 1px;
  overflow: auto;
}
.open-lately-expand {
  height: 65.8vw;
}
table {
  border-spacing: 0;
  border-collapse: collapse;
  background: #fff;
  border-bottom: 1px solid #dedede;
  color: #8994b1;
}
.open-lately th {
  line-height: 7.8vw;
  font-weight: normal;
}
.bg-grey {
  background: #f2f5f8;
}

/* 下注总信息 */
.bets-total {
  width: 100%;
  padding: 0 2vw;
  background: #eee;
  line-height: 8vw;
}

/* 底部固定栏 */
.hecai-bottom {
  width: 100%;
  padding: 2vw 2vw;
  line-height: 6.5vw;
  border-top: 1px solid #e1e1e1;
}
.hecai-btn {
  border: 1px solid;
  padding: 0 3vw;
  border-radius: 4px;
}
.random-btn {
  background: #ffefef;
  color: #e64100;
  border-color: #e64100;
}
.submit-btn {
  background: #eee;
  border-color: #eee;
  color: #afafaf;
  transition: 0.5s;
}
.cansubmit {
  background: #e64600;
  border-color: #e64600;
  color: #fff;
}
.bets-per-gold input {
  margin: 0 1vw;
  width: 15vw;
  border: 1px solid #d4d4d4;
  line-height: 6.5vw;
  color: #e64600;
  border-radius: 4px;
  transition: 0.5s;
}
.bets-per-gold input:focus {
  border-color: currentColor;
}

/* 玩法规则弹窗 */
.modal {
  transition: 0.25s;
}
.fadeIn-enter .modal {
  transform: translate3d(100%, 0, 0);
}
.fadeIn-leave-active .modal {
  transform: translate3d(100%, 0, 0);
}
.example-modal .modal-title {
  background: #e64600;
  color: #fff;
  line-height: 40px;
}
.example-modal .modal-body {
  padding: 10px;
  padding-bottom: 30px;
}
.example-title {
  line-height: 2;
  font-weight: bold;
}
.example-title .iconfont {
  margin-right: 5px;
}
.example-content {
  padding: 0 1.5em 0;
  font-size: 14px;
}
</style>
