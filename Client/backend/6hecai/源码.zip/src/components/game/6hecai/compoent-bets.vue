<template>
  <div :class="needScroll"
       class="odds-main">
    <!-- 不同的赔率展示 -->
    <div v-if="normal"
         class="odds flex bgc-fff">

      <label v-for="(objValue,objKey) in betsObj"
             :key="objKey"
             class="odds-item">
        <input type="checkbox"
               :value="objKey"
               v-model="value"
               class="dent-bg-input hidden">
        <div :class="getColor && getColorFunc(objKey)"
             class="bg flex flow-col justify-ct">
          <span class="odds-bets">{{objKey | keyToCharacter(type,currentSubOdds)}}</span>
          <span class="odds-num font-th  eme">赔率: <input style="text-align: center;width: 60px;border-radius: 30%;"
                   type="number"
                   :value="objValue"
                   @change="changebets($event,objKey)"></span>
        </div>
      </label>

    </div>

    <div v-if="needToShowNum"
         class="odds flex bgc-fff">

      <label v-for="(objValue,key) in betsObj"
             :key="key"
             class="odds-item wx-odds-item ">
        <input type="checkbox"
               :value="key"
               v-model="value"
               class="dent-bg-input hidden">
        <div class="bg flex flow-col justify-ct">
          <span class="odds-bets">{{key | keyToCharacter}}</span>
          <span class="odds-num font-theme">赔率:
            <input style="text-align: center;width: 60px;border-radius: 30%;"
                   type="number"
                   :value="objValue"
                   @change="changebets($event,key)">
          </span>
          <div v-if="type === 'qmwx'"
               class="wx-num flex">
            <span v-for="n in haoma.wx[key]"
                  :key="n">{{ n.toString().length === 1 ? '0'+n : n }}</span>
          </div>
          <div v-else-if="type === 'shx' || type === 'lqlw' || currentSubOdds === 'hq'"
               class="wx-num flex">
            <span v-for="n in haoma.animals[key]"
                  :key="n">{{ n.toString().length === 1 ? '0'+n : n }}</span>
          </div>
        </div>
      </label>

    </div>

    <div v-if="showAllNum"
         class="odds flex bgc-fff">

      <template v-if="betsObj instanceof Object">
        <p v-for="(value,key) in betsObj"
           :key="key"
           style="color:red">修改赔率：<input style="margin-left:10px"
                 :value="value"
                 type="number"
                 @change="changebets($event,key)"></p>
      </template>
      <p v-else
         style="color:red">修改赔率：<input style="margin-left:10px"
               :value="betsObj"
               type="number"
               @change="changebets($event,currentSubOdds)"></p>

      <!-- <label v-for="n in 49"
             class="odds-item showAllNum-item">
        <input type="checkbox"
               :value="n"
               v-model="value"
               class="dent-bg-input hidden">
        <div class="bg flex flow-col justify-ct">
          <span class="odds-bets">{{n}}</span>
        </div>
      </label> -->

    </div>

    <div v-if="showAllNumAndNum"
         class="odds flex bgc-fff">

      <label v-for="(objvalue,objkey,objindex) in betsObj"
             :key="objkey"
             class="odds-item showAllNum-item">
        <input type="checkbox"
               :value="objkey"
               v-model="value"
               class="dent-bg-input hidden">
        <div class="bg flex flow-col justify-ct">
          <span class="odds-bets">{{(objindex+1).toString().length === 1 ? '0'+ (objindex+1) : (objindex+1)}}</span>
        </div>
        <span class="font-theme showAllNumAndNum"><input style="text-align: center;width: 40px;border-radius: 30%;"
                 :value="objvalue"
                 type="number"
                 @change="changebets($event,objkey)"> </span>
      </label>

    </div>

    <!-- 正码过关 特殊处理 -->
    <template v-if="currentSubOdds == 'zhmgg'">
      <div v-for="(objValue,objKey,objindex) in betsObj"
           :key="objKey"
           class="odds odds-zhmgg flex bgc-fff">

        <div class="zhmgg">正码{{objindex | numToCharacter}}</div>

        <label v-for="(subValue,subKey) in objValue"
               :key="subKey"
               class="odds-item">
          <input type="radio"
                 :value="subKey"
                 v-model="zhmggValue[objKey]"
                 class="dent-bg-input hidden">
          <div :class="getColor && getColorFunc(subKey)"
               class="bg flex flow-col justify-ct">
            <span class="odds-bets">{{subKey | keyToCharacter(type,currentSubOdds)}}</span>
            <!-- onchange="changebets(this.id)" -->
            <span class="odds-num font-theme">赔率:
              <!-- <input style="text-align: center;width: 60px;border-radius: 30%;" type="text" v-model="odds[objKey][subKey]"> </span> -->
              <input style="text-align: center;width: 60px;border-radius: 30%;"
                     type="text"
                     :value="subValue"
                     @change="changebets($event,subKey)"> </span>
          </div>
        </label>

      </div>
    </template>

  </div>
</template>

<script>
import { keyToCharacter } from "@/js/6hecai-odds";

export default {
  props: {
    betsObj: [Array, Object], //需要渲染的对象或者数组
    type: String, //组件的 type 用来切换不同的赔率展示方式
    currentSubOdds: String, //当前的子玩法 用来切换不同的赔率展示方式
    activeTab: [String, Number], //6合彩页面 激活tab，配合 type 切换不同的赔率展示方式
    value: Array, //value 用来接受v-model传进来的值
    haoma: Object //生肖和五行号码
  },
  filters: {
    // 键值转成中文
    keyToCharacter: function(value, type, currentSubOdds) {
      let character = "";
      //正码过关 和 正码1-6 翻译都一样,key不一样，
      //为了提升性能，和后台商量key改为 key_dan的形式，取dan遍历
      // let needSplit = ['zhmgg','qsb','ssb'].includes(currentSubOdds) || type === 'zhm1-6';
      if (value.match(/_/)) value = value.split("_")[1];

      for (let key in keyToCharacter) {
        if (key === value) {
          character = keyToCharacter[key];
          break;
        }
      }

      if (!character) character = value;
      return character;
    },
    // 数字转成中文
    numToCharacter: function(index) {
      let arr = ["一", "二", "三", "四", "五", "六"];

      return arr[index];
    }
  },
  data() {
    return {
      normal: false,
      needToShowNum: false,
      showAllNum: false,
      showAllNumAndNum: false,
      getColor: false, //是否需要红绿蓝色波
      //正码过关的v-model绑定
      zhmggValue: {
        zhy: "",
        zher: "",
        zhs: "",
        zhsi: "",
        zhw: "",
        zhl: ""
      }
    };
  },
  computed: {
    needScroll() {
      let need = ["zhmgg", "zhm", "tm", "lm", "hq"].includes(
        this.currentSubOdds
      );
      return need ? "odds-main-ovfa" : "";
    }
  },
  methods: {

    //修改赔率，把数据传到主页6hecai
    changebets(e, key) {
      let data;
      let leiXin = this.type && this.currentSubOdds;
      let type = this.type || this.currentSubOdds;
      if(leiXin === undefined) {leiXin = ''};

      data = {
        key,
        value: e.target.value,
        type,
        leiXin
      };
      //特殊处理
      let noLeixin = ["zh1","zh2","zh3","zh4","zh5","zh6"].includes(this.currentSubOdds) ||this.showAllNum;

      let IfLmaSub = ["3lmaszher", "2lmaerzht"].includes(this.currentSubOdds);

      if (noLeixin && !IfLmaSub) {
        data = {
          key,
          value: e.target.value,
          type,
          leiXin: ""
        };
      }

      this.$emit("changebets", data);
    },

    // 根据色波的key值的后缀 ,返回不同的颜色类名 , 比如 ssbhb_h 也就是_h返回font_red
    getColorFunc(objKey) {
      const color = {
        hong:'font_red',
        lan:'font_blue',
        lv:'font_green'
      }
      let key = objKey.split('_')[1];
      return color[key];
    }
  },

  watch: {
    //value，向外部派发下注的信息
    value(value) {
      this.$emit("input", value);
    },
    //zhmggValue，向外部派发下注的信息
    zhmggValue: {
      handler(zhmggValue) {
        this.$emit("input", zhmggValue);
      },
      deep: true
    },
    currentSubOdds: {
      handler(currentSubOdds) {
        //显示 名字 赔率
        let normal = [
          "lm",
          "qm",
          "twsh",
          "zhtwsh",
          "bb",
          "bbb",
          "qsb",
          "ssb",
          "zq",
          "2lw",
          "3lw",
          "4lw",
          "5lw",
          "zh1",
          "zh2",
          "zh3",
          "zh4",
          "zh5",
          "zh6"
        ];
        //显示 名字 赔率 号码
        let needToShowNum = [
          "wx",
          "tq",
          "yq",
          "zhq",
          "2lq",
          "3lq",
          "4lq",
          "5lq",
          "hq"
        ];
        //显示 1-49
        let showAllNum = [
          "zxbzh10bzh",
          "zxbzh11bzh",
          "zxbzh12bzh",
          "zxbzh5bzh",
          "zxbzh6bzh",
          "zxbzh7bzh",
          "zxbzh8bzh",
          "zxbzh9bzh",
          "2lmaerqzh",
          "2lmaerzht",
          "4lmasiqzh",
          "3lmasqzh",
          "3lmaszher",
          "2lmatch",
          "zhy5zh1",
          "zhy6zh1",
          "zhy7zh1",
          "zhy8zh1",
          "zhy9zh1",
          "zhy10zh1"
        ];
        //显示 1-49 赔率
        let showAllNumAndNum = [
          "zhert",
          "zhlt",
          "zhsit",
          "zhst",
          "zhwt",
          "zhyt",
          "zhm",
          "tm"
        ];

        this.normal = normal.includes(currentSubOdds);
        this.needToShowNum = needToShowNum.includes(currentSubOdds);
        this.showAllNum = showAllNum.includes(currentSubOdds);
        this.showAllNumAndNum = showAllNumAndNum.includes(currentSubOdds);

        //色波 红 绿 蓝 渲染不同的颜色
        if (
          [
            "bb",
            "bbb",
            "qsb",
            "ssb",
            "zh1",
            "zh2",
            "zh3",
            "zh4",
            "zh5",
            "zh6",
            "zhmgg"
          ].includes(currentSubOdds)
        ) {
          this.getColor = true;
        }
      },
      immediate: true
    }
  }
};
</script>

<style scoped>
.hidden {
  display: none;
}
.font_red {
  color: #cc0000;
}
.font_blue {
  color: #0e86e3;
}
.font_green {
  color: #38be4f;
}
/* 下注信息展示区 */
.odds-main {
  flex: 1;
  position: relative;
  width: 100%;
}
.odds-main-ovfa {
  overflow: auto;
}
.odds-tips,
.zhmgg {
  position: absolute;
  z-index: 1;
  top: 2vw;
  padding: 0 2vw;
  background: #f4f6f9;
  color: #7f8baa;
  line-height: 6vw;
}
.odds-tips {
  right: 0;
  border-top-left-radius: 3vw;
  border-bottom-left-radius: 3vw;
}
.odds-tips .iconfont {
  font-size: 13px;
}
.odds-zhmgg {
  position: relative;
}
.zhmgg {
  left: 0;
  border-top-right-radius: 3vw;
  border-bottom-right-radius: 3vw;
}
.odds {
  flex: 1;
  flex-wrap: wrap;
  padding-top: 4vw;
  padding-right: 6vw;
  padding-bottom: 6vw;
  line-height: 1.6;
}
.odds-item {
  margin-left: 6vw;
  margin-top: 6vw;
  width: calc(100% / 3 - 6vw);
  height: 14vw;
  box-sizing: border-box;
}
.showAllNum-item {
  margin-top: 8.3vw;
  margin-left: 8.3vw;
  width: 10vw;
  height: 10vw;
  background: #f7f9fa;
  border-radius: 50%;
}
.showAllNum-item .bg {
  border-radius: 50%;
}
.showAllNumAndNum {
  line-height: 2;
}
.odds-bets {
  font-size: 16px;
}
.odds-num {
  font-size: 14px;
}
.bg {
  width: 110%;
  height: 110%;
  border: 1px solid #c9c9c9;
  border-radius: 4px;
  transition: 0.5s;
}
.bg span {
  transition: 0.5s;
}
/* 5行 */
.wx-odds-item {
  height: auto;
}
.wx-num {
  flex-wrap: wrap;
  margin: 0 0 2vw 2vw;
  font-size: 12px;
}
.wx-num span {
  margin-right: 0.5em;
}
</style>
