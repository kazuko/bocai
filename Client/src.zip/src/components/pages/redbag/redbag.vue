<template>
    <div>
        <mt-header title="我的红包">
            <router-link to="/" slot="left">
                <mt-button icon="back">返回</mt-button>
            </router-link>
        </mt-header>
    </div>
</template>

<script>
console.log("PAGES_REDBAG_REDBAG_VUE");
    export default {
        
    }
</script>

<style scoped>

</style>