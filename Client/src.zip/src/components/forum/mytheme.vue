<template>
    <div>
        <mt-header title="我的帖子">
            <router-link to="/user" slot="left">
                <mt-button icon="back">返回</mt-button>
            </router-link>
        </mt-header>
    </div>
</template>
<script>
export default {};
</script>
<style scoped>
</style>

