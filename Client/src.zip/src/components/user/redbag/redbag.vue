<template>
    <div>
        <mt-header title="我的红包" fixed='true'>
            <router-link to="/user" slot="left">
                <mt-button icon="back">返回</mt-button>
            </router-link>
        </mt-header>
    </div>
</template>

<script>
console.log("USER_REDBAG_REDBAG_VUE");
    export default {
        data(){
            return {

            }
        },
        
    }
</script>

<style scoped>

</style>