<template>
    <div>

    </div>
</template>

<script>
console.log("USER_MEDAL_MEDALDETAIL_VUE");
    export default {
        
    }
</script>

<style scoped>

</style>