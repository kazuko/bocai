// 注册API
// const mySystem = process.env.mySystem;
// const personal = process.env.personal;
// const transPsd = process.env.transPsd
// 获取勋章
// const medal = process.env.medal;
// 添加朋友
// const addFriend = process.env.addFriend;
// 
// const sendAdd = process.env.sendAdd;
// const friend = process.env.friend;
// const strange = process.env.strange;
// const theme = process.env.theme;
// const post = process.env.post;

// // 登陆
// const login = "http://bc.gd-dent.com/bcweb/index.php/Home/Login/login";
// // 注册
// const regist = "http://bc.gd-dent.com/bcweb/index.php/Home/login/register";
// const forum = "http://bc.gd-dent.com/bcweb/index.php/Forum/forums/forum_list";
// const forumLike = "http://bc.gd-dent.com/bcweb/index.php/Forum/forums/forum_post_like";
// const appInfo = "http://bc.gd-dent.com/bcweb/index.php/Home/Login/appInfo";
// const logout = "http://bc.gd-dent.com/bcweb/index.php/Home/Login/logout";

// 登陆
// const login = process.env.HOST + "/bcweb/index.php/Home/Login/login";
// 注册
// const regist = process.env.HOST + "/bcweb/index.php/Home/login/register";
// const forum = process.env.HOST + "/bcweb/index.php/Forum/forums/forum_list";
// const forumLike = process.env.HOST + "/bcweb/index.php/Forum/forums/forum_post_like";
// const appInfo = process.env.HOST + "/bcweb/index.php/Home/Login/appInfo";
// const logout = process.env.HOST + "/bcweb/index.php/Home/Login/logout";
export default {
    // login,
    // regist, 
    // forum,
    // forumLike,
    // appInfo,
    // logout,
    // mySystem, 
    // personal, 
    // transPsd, 
    // medal, 
    // addFriend, 
    // sendAdd, 
    // friend, 
    // strange, 
    // theme,
    // post, 
}

console.log("CONFIG_ROOT.JS");
